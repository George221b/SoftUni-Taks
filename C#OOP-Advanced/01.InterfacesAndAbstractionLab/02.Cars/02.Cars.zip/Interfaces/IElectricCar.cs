﻿
    public interface IElectricCar
    {
        int Batteries { get; }
    }

