﻿using System;
using NUnit.Framework;

namespace Skeleton.Tests
{
    [TestFixture]
    class AxeTests
    {
        [Test]
        public void AxeLosesDurabilyAfterAttack()
        {
            // Arrange
            Axe axe = new Axe(10, 10);
            Dummy dummy  = new Dummy(100, 100);

            // Act
            axe.Attack(dummy);

            // Assert
            Assert.AreEqual(9, axe.DurabilityPoints, "Axe does not lose durability");
        }

        [Test]
        public void AtackWithBrokenWeapon()
        {
            //Arange
            Axe axe = new Axe(10, 1);
            Dummy dummy = new Dummy(100, 100);

            //Act
            axe.Attack(dummy);

            //Assert
            var ex = Assert.Throws<InvalidOperationException>(() => axe.Attack(dummy));
            Assert.That(ex.Message, Is.EqualTo("Axe is broken."));
        }
    }
}
