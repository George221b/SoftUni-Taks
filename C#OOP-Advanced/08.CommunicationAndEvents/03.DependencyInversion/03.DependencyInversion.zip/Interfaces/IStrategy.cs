﻿namespace _03.DependencyInversion.Interfaces
{
    public interface IStrategy
    {
        int Calculate(int first, int second);
    }
}
