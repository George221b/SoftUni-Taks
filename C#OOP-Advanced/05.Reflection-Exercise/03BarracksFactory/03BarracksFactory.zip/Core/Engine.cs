﻿using System.Linq;
using System.Reflection;
using _03BarracksFactory.Core.Commands;

namespace _03BarracksFactory.Core
{
    using System;
    using Contracts;

    class Engine : IRunnable
    {
        private IRepository repository;
        private IUnitFactory unitFactory;
        private ICommandInterpreter commandInterpreter;

        public Engine(IRepository repository,
            IUnitFactory unitFactory,
            ICommandInterpreter commandInterpreter)
        {
            this.repository = repository;
            this.unitFactory = unitFactory;
            this.commandInterpreter = commandInterpreter;
        }
        
        public void Run()
        {
            while (true)
            {
                try
                {
                    string input = Console.ReadLine();
                    string[] data = input.Split();
                    string commandName = data[0];

                    IExecutable command = this.commandInterpreter.InterpretCommand(data, commandName);
                    string result = command.Execute();
                    //string result = InterpredCommand(data, commandName);
                    Console.WriteLine(result);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }
        }

        // TODO: refactor for Problem 4
        //private string InterpredCommand(string[] data, string commandName)
        //{
        //    var result = string.Empty;

        //    try
        //    {
        //        Assembly currentAssembly = Assembly.GetExecutingAssembly();
        //        Type currentType = currentAssembly.GetTypes().SingleOrDefault(t => string.Equals(t.Name, commandName, StringComparison.CurrentCultureIgnoreCase));
        //        IExecutable command = (Command)Activator.CreateInstance(currentType, data, this.repository, this.unitFactory);
        //        result = command.Execute();
        //    }
        //    catch (Exception)
        //    {
        //        throw new InvalidOperationException("Invalid command!");
        //    }

        //    return result;
        //}
    }
}
