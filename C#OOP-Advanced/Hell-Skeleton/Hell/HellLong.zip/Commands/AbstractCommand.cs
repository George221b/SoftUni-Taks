﻿public abstract class AbstractCommand
{
    public abstract string Execute();
}
