﻿public class HeroConstants
{
    public const int BarbarianStrength = 90;
    public const int BarbarianAgility = 25;
    public const int BarbarianIntelligence = 10;
    public const int BarbarianHitPoints = 350;
    public const int BarbarianDamage = 150;

    public const int AssassinStrength = 25;
    public const int AssassinAgility = 100;
    public const int AssassinIntelligence = 15;
    public const int AssassinHitPoints = 150;
    public const int AssassinDamage = 300;

    public const int WizardStrength = 25;
    public const int WizardAgility = 25;
    public const int WizardIntelligence = 100;
    public const int WizardHitPoints = 100;
    public const int WizardDamage = 250;
}