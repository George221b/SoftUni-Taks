﻿namespace _05.CardCompareTo.Enums
{
    public enum CardSuit
    {
        Clubs,
        Diamonds,
        Hearts,
        Spades
    }
}
