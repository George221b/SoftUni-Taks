﻿using _11.InfernoInfinity.Core;

namespace _11.InfernoInfinity
{
    public class Startup
    {
        public static void Main()
        {
            var engine = new Engine();
            engine.Run();
        }
    }
}
