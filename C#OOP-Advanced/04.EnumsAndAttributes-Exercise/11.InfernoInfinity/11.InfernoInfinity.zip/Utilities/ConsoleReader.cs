﻿using System;

namespace _11.InfernoInfinity.Utilities
{
    public static class ConsoleReader
    {
        public static string ReadLine()
        {
            return Console.ReadLine();
        }
    }
}
