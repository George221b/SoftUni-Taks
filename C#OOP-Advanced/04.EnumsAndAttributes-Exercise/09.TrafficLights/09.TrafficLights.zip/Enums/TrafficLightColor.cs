﻿namespace _09.TrafficLights.Enums
{
    public enum TrafficLightColor
    {
        Red,
        Green,
        Yellow
    }
}
