﻿namespace _10.CreateCustomClassAttribute
{
    [Custom("Pesho" , 3, "Used for C# OOP Advanced Course - Enumerations and Attributes.", "Pesho", "Svetlio")]
    public class Weapon
    {
    }
}
