﻿namespace _03._04.CardPower.Enums
{
    public enum CardSuit
    {
        Clubs,
        Diamonds,
        Hearts,
        Spades
    }
}
