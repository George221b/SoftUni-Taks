﻿namespace _07.DeckOfCards.Enums
{
    public enum CardSuit
    {
        Clubs,
        Diamonds,
        Hearts,
        Spades
    }
}