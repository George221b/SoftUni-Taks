﻿using System;

namespace _06.BirthdayCelebrations.Interfaces
{
    interface IAnimal
    {
        string Name { get; }
        string Birthday { get; }
    }
}
