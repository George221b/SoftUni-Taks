﻿namespace _04.Telephony.Interfaces
{
    public interface ICallable
    {
        string Call(string number);
    }
}
