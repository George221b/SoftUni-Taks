﻿namespace _04.Telephony.Interfaces
{
    public interface IBrowsable
    {
        string Browse(string url);
    }
}
