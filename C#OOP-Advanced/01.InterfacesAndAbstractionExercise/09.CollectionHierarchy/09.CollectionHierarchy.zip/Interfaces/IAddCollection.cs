﻿namespace _09.CollectionHierarchy.Interfaces
{
    public interface IAddCollection
    {
        int Add(string item);
    }
}
