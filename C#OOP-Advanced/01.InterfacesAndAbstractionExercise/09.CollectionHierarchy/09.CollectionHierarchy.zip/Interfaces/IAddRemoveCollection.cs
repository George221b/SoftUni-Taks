﻿using System.Collections.Generic;

namespace _09.CollectionHierarchy.Interfaces
{
    public interface IAddRemoveCollection : IAddCollection
    {
        string Remove();
    }
}