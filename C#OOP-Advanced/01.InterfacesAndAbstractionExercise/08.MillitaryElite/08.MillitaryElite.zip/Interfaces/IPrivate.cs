﻿namespace _08.MillitaryElite.Interfaces
{
    public interface IPrivate : ISoldier
    {
        double Salary { get; }
    }
}
