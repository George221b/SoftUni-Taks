﻿namespace _08.MillitaryElite.Interfaces
{
    public interface ISpy : ISoldier
    {
        int CodeNumber { get; }
    }
}