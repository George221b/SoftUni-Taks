﻿namespace _05.BorderControl.Interfaces
{
    public interface IIdentifiable
    {
        string Id { get; }
    }
}
