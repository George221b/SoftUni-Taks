﻿using System;
using System.Collections.Generic;

public static class HarvesterFactory
{
    public static Harvester GetHarvester(List<string> arguments)
    {
        string type = arguments[0];
        string id = arguments[1];
        double oreOutput = double.Parse(arguments[2]);
        double energyRequirment = double.Parse(arguments[3]);

        switch (type)
        {
            case "Hammer":
                return new HammerHarvester(id, oreOutput, energyRequirment);
                break;
            case "Sonic":
                return new SonicHarvester(id, oreOutput, energyRequirment, int.Parse(arguments[4]));
                break;
            default:
                throw new ArgumentException("Harvester failed to be created.");
                break;
        }
    }
}